<?php

namespace Modules\BundleSubscription\Database\Seeders;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;

class BundleSubscriptionDatabaseSeeder extends Seeder
{
    public function run()
    {
        Model::unguard();

    }
}
