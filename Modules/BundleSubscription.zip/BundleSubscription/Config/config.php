<?php

return [
    'name' => 'BundleSubscription'
];
