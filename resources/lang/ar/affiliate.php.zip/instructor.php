<?php

return [
 'Instructors' => 'المدرسون',
    'Add Instructor' => 'إضافة مدرس',
    'About' => 'نبذة عن',
    'Date of Birth' => 'تاريخ الميلاد',
    'Payout Lists' => 'قوائم الدفع',
    'Payout' => 'الدفع',
    'Instructor' => 'المدرس'
];
