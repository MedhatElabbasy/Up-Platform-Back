<?php

return [
    'Instructor' => 'Instructor',
    'Amount' => 'Amount',
    'Invoice Date' => 'Invoice Date',
    'Method' => 'Method',
    'Issue Date' => 'Issue Date',
    'Waiting' => 'Waiting',
    'Instructor Payment' => 'Instructor Payment',
    'Approved' => 'Approved',
    'Rejected' => 'Rejected',
    'Next Payout' => 'Next Payout',
    'You Currently Have' => 'You Currently Have',
    'in earnings for next months payout' => 'in earnings for next months payout',
    'Payout Account' => 'Payout Account',
    'Set Account' => 'Set Account',
    'Payout Email' => 'Payout Email',
    'Set Payout' => 'Set Payout',
    'Payout Email Saved Successfully' => 'Payout Email Saved Successfully',
    'Request Date' => 'Request Date',
    'Payment Status' => 'Payment Status',
    'Payment Request' => 'Payment Request',
    'Are you Sure, You want to request for payment?' => 'Are you Sure, You want to request for payment?',
    'Confirm' => 'Confirm',
    'Are you Sure, You want to mark as payment?' => 'Are you Sure, You want to mark as payment?',
    'Request for payment'=>'Request for payment'
];
