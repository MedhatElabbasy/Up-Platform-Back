<?php
return [
 'Communication' => 'التواصل',
    'Questions & Answer' => 'الأسئلة والأجوبة',
    'Private Messages' => 'الرسائل الخاصة',
    'Message List' => 'قائمة الرسائل',
    'Write your message' => 'اكتب رسالتك',
    'Search content here' => 'ابحث عن المحتوى هنا',
    'Short Code' => 'الكود القصير',
    'Field Name' => 'اسم الحقل',
    'Subscriptions' => 'الاشتراكات',
    'Send Message' => 'إرسال رسالة',
    'Send Email' => 'إرسال بريد إلكتروني',
    'Compose Message' => 'إنشاء رسالة',
    'Your referral link' => 'رابط الإحالة الخاص بك',
    'Copy Link' => 'نسخ الرابط',
    'Share the referral link with your friends.' => 'شارك رابط الإحالة مع أصدقائك.',
    'Your referral list' => 'قائمة الإحالة الخاصة بك',
    "Let's say Hi" => "لنقل مرحبًا",
    'News Category' => 'فئة الأخبار',
    'News List' => 'قائمة الأخبار'
];
