<?php

return [
    'Members' => 'Members',
    'Registered Members' => 'Registered Members',
    'Last Submission' => 'Last Submission',
    'Enabled' => 'Enabled',
    'Disabled' => 'Disabled',
    'Enable' => 'Enable',
    'Disable' => 'Disable',
    'View' => 'View',
    'Name' => 'Name',
    'Email' => 'Email',
    'Phone' => 'Phone',
    'Registration Status' => 'Registration Status',
    'Submission Date' => 'Submission Date',
    'Export' => 'Export',
    'Export List' => 'Export List',
    'Send Notification' => 'Send Notification',
    'Choose which columns you see' => 'Choose which columns you see',
    'Cancel' => 'Cancel'

];
