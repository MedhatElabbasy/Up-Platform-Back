<?php

return [
    'TAX' => 'TAX',
    'Tax' => 'Tax',
    'TAX Setting' => 'TAX Setting',
    'Percentage' => 'Percentage',
    'Apply TAX' => 'Apply TAX',
    'TAX Type' => 'TAX Type',
    'Common Tax' => 'Common Tax',
    'Country Wish Tax' => 'Country Wish Tax',
    'Update tax percentage from  Country Wish Tax section' => 'Update tax percentage from  Country Wish Tax section',
    'Country Wish Tax List' => 'Country Wish Tax List',
    'Country' => 'Country',
    'Tax List' => 'Tax List',
    'Add New Tax' => 'Add New Tax',
    'Update Tax'=>'Update Tax'

];
