<?php
return [
    'Communication' => 'Communication',
    'Questions & Answer' => 'Questions & Answer',
    'Private Messages' => 'Private Messages',
    'Message List' => 'Message List',
    'Write your message' => 'Write your message',
    'Search content here' => 'Search content here',
    'Short Code' => 'Short Code',
    'Field Name' => 'Field Name',
    'Subscriptions' => 'Subscriptions',
    'Send Message' => 'Send Message',
    'Send Email' => 'Send Email',
    'Compose Message' => 'Compose Message',
    'Your referral link' => 'Your referral link',
    'Copy Link' => 'Copy Link',
    'Share the referral link with your friends.' => 'Share the referral link with your friends.',
    'Your referral list' => 'Your referral list',
    "Let's say Hi" => "Let's say Hi",
    'News Category'=>'News Category',
    'News List'=>'News List'
];
