<?php

return [
    'Homework' => 'Homework',
    'Homework Not Found !' => 'Homework Not Found',
    'Homework List' => 'Homework List',
    'My Homework' => 'My Homework',
    'Add' => 'Add',
    'Available For' => 'Available For',
    'Marks' => 'Marks',
    'Min Percentage' => 'Min Percentage',
    'Description' => 'Description',
    'Attachment' => 'Attachment',
    'Submit Date' => 'Submit Date',
    'Select Related Course' => 'Select Related Course',
    'Answer' => 'Answer',
    'Assign' => 'Assign',
    'Upload' => 'Upload',
    'History' => 'History',
    'Marking' => 'Marking',
    'Obtain Marks' => 'Obtain Marks',
    'Study Material' => 'Study Material',
    'Study Material List' => 'Study Material List',
    'Not Assigned' => 'Not Assigned',
    'Pass' => 'Pass',
    'Fail' => 'Fail',
    'Not Marked' => 'Not Marked',
    'Not Submitted' => 'Not Submitted'


];

