<?php
return [
    'Sponsor Saved Successfully' => 'Sponsor Saved Successfully',
    'Sponsor Deleted Successfully' => 'Sponsor Deleted Successfully',
    'Sponsor Updated Successfully' => 'Sponsor Updated Successfully',
    'Sponsors' => 'Sponsors',
    'Add New Sponsor' => 'Add New Sponsor',
    'Image' => 'Image',
    'Title' => 'Title',
    'Sponsor List' => 'Sponsor List',
    'Frontend CMS' => 'Frontend CMS',
];
