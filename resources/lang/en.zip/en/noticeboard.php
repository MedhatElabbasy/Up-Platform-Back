<?php
return [
    'Noticeboard' => 'Noticeboard',
    'Sender' => 'Sender',
    'Type' => 'Type',
    'Send At' => 'Send At',
    'Notice Type' => 'Notice Type',
    'Message' => 'Message',
    'General' => 'General',
    'Notice' => 'Notice'
];
