<?php

return [
    'Assignment' => 'Assignment',
    'Assignment Not Found !' => 'Assignment Not Found',
    'Assignment List' => 'Assignment List',
    'Add' => 'Add',
    'Marks' => 'Marks',
    'Min Percentage' => 'Min Percentage',
    'Description' => 'Description',
    'Attachment' => 'Attachment',
    'Submit Date' => 'Submit Date',
    'Select Related Course' => 'Select Related Course',
    'Assign' => 'Assign',
    'Upload' => 'Upload',
    'History' => 'History',
    'Marking' => 'Marking',
    'Obtain Marks' => 'Obtain Marks',
    'Anonymous' => 'Anonymous',
    'Staff' => 'Staff',
    'Instructor' => 'Instructor',
    'Student' => 'Student',
    'Specific User' => 'Specific User',
    'Not Assigned' => 'Not Assigned',
    'Pass' => 'Pass',
    'Fail' => 'Fail',
    'Not Marked' => 'Not Marked',
    'Not Submitted' => 'Not Submitted'
];

