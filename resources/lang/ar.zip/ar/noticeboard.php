<?php
return [
'Noticeboard' => 'لوحة الإعلانات',
'Sender' => 'المُرسِل',
'Type' => 'النوع',
'Send At' => 'إرسال في',
'Notice Type' => 'نوع الإعلان',
'Message' => 'الرسالة',
'General' => 'عام',
'Notice' => 'إعلان'
];
