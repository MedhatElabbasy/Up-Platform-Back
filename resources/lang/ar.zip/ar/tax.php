<?php

return [
'TAX' => 'ضريبة',
'Tax' => 'ضريبة',
'TAX Setting' => 'إعداد الضريبة',
'Percentage' => 'النسبة المئوية',
'Apply TAX' => 'تطبيق الضريبة',
'TAX Type' => 'نوع الضريبة',
'Common Tax' => 'الضريبة الشائعة',
'Country Wish Tax' => 'الضريبة حسب البلد',
'Update tax percentage from Country Wish Tax section' => 'تحديث نسبة الضريبة من قسم الضريبة حسب البلد',
'Country Wish Tax List' => 'قائمة الضريبة حسب البلد',
'Country' => 'البلد',
'Tax List' => 'قائمة الضرائب',
'Add New Tax' => 'إضافة ضريبة جديدة',
'Update Tax' => 'تحديث الضريبة',


];
