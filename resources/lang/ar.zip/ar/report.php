<?php
return [
"Admin Course Revenue List" => "قائمة إيرادات الدورة للإدارة",
"Report" => "تقرير",
"Admin Revenue" => "إيرادات الإدارة",
"With Discount" => "بخصم",
"Without Discount" => "بدون خصم",
"Start Date" => "تاريخ البدء",
"End Date" => "تاريخ الانتهاء",
"Enrolled Student" => "الطلاب المسجلين",
"Price" => "السعر",
"Revenue" => "الإيرادات",
"Discount" => "الخصم",
"Enrolled Date" => "تاريخ التسجيل",
"Purchase ID" => "معرف الشراء",
"Scorm Report" => "تقرير Scorm",
"XAPI Report" => "تقرير XAPI",
"H5P" => "H5P",
"H5P Info" => "معلومات H5P",
"Score" => "النتيجة",
"Total Score" => "النتيجة الإجمالية",
"H5P Report" => "تقرير H5P",

];
