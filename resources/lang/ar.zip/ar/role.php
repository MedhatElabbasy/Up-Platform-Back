<?php

return [
'Role List' => 'قائمة الأدوار',
'Role' => 'دور',
'Instructor Role' => 'دور المدرب',
'Details' => 'تفاصيل',
'Role has been added Successfully' => 'تمت إضافة الدور بنجاح',
'Role has been updated Successfully' => 'تم تحديث الدور بنجاح',
'Edit Role Info' => 'تعديل معلومات الدور',
'Role has been deleted Successfully' => 'تم حذف الدور بنجاح',
'Permission' => 'صلاحية',
'Menu' => 'القائمة',
'Sub-Menu' => 'القائمة الفرعية',
'assign_permission' => 'تخصيص الصلاحية',
'role_permission' => 'صلاحية الدور',
'Student Role' => 'دور الطالب',

];
