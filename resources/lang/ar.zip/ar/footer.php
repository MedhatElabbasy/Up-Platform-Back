<?php

return [
'Footer' => 'تذييل الصفحة',
'Footer Settings' => 'إعدادات التذييل',
'Dashboard' => 'لوحة التحكم',
'Frontend CMS' => 'نظام إدارة المحتوى للواجهة الأمامية',
'Copyright Text' => 'نص حقوق النشر',
'About Text' => 'نص حول',
'Section name' => 'اسم القسم',
'About Description' => 'وصف حول',
'Add New Page' => 'إضافة صفحة جديدة',
'Cancel' => 'إلغاء',
'Widget' => 'قطعة',
'Page Name' => 'اسم الصفحة',
'Edit Link' => 'تحرير الرابط',
'Widget Title' => 'عنوان القطعة',
'Add Link' => 'إضافة رابط',
'Select Page' => 'اختيار الصفحة',
'Are you sure' => 'هل أنت متأكد'

];
