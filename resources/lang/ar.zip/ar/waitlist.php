<?php

return [
'Members' => 'الأعضاء',
'Registered Members' => 'الأعضاء المسجلين',
'Last Submission' => 'آخر إرسال',
'Enabled' => 'مُمكّن',
'Disabled' => 'مُعطل',
'Enable' => 'تمكين',
'Disable' => 'تعطيل',
'View' => 'عرض',
'Name' => 'الاسم',
'Email' => 'البريد الإلكتروني',
'Phone' => 'الهاتف',
'Registration Status' => 'حالة التسجيل',
'Submission Date' => 'تاريخ الإرسال',
'Export' => 'تصدير',
'Export List' => 'قائمة التصدير',
'Send Notification' => 'إرسال إشعار',
'Choose which columns you see' => 'اختر الأعمدة التي تريد رؤيتها',
'Cancel' => 'إلغاء',


];
