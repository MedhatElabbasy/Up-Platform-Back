<?php
return [
'BulkPrint' => 'طباعة جماعية',
'No Student Found' => 'لم يتم العثور على طلاب'
];
