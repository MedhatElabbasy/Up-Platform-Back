<?php

return [
    'Department' => 'قسم',
];
