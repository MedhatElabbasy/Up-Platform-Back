<?php

return [
 'Saas Branch' => 'فرع Saas',
'Branches' => 'فروع',
'Branch' => 'فرع',
'Domain' => 'نطاق',
'Student' => 'طالب',
'Instructor' => 'مدرب',
'Admin' => 'مدير',
'min 3 latter' => '3 حروف كحد أدنى',
'Courses in this branch' => 'الدورات في هذا الفرع',
'Domain Already Exist.' => 'النطاق موجود بالفعل.',
   'You must have active LmsSaas Module.' => 'يجب أن تكون لديك وحدة LmsSaas نشطة.',
'Default User Type' => 'نوع المستخدم الافتراضي',
'You cannot add a branch because you are in the main domain. Subdomain Required.' => 'لا يمكنك إضافة فرع لأنك في النطاق الرئيسي. النطاق الفرعي مطلوب.'




];
