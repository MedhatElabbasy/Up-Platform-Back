<?php
return [
 "welcome_description" => "شكرًا لاختيارك InfixLMS لنظام إدارة التعلم. يرجى اتباع الخطوات لاستكمال تثبيت InfixLMS!",
'install_with_seed' => 'التثبيت مع بيانات تجريبية',
'phone' => 'الهاتف',
'address' => 'العنوان',
'site_title' => 'عنوان الموقع',


];
