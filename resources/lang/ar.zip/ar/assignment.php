<?php

return [
'Assignment' => 'مهمة',
'Assignment Not Found !' => 'المهمة غير موجودة!',
'Assignment List' => 'قائمة المهام',
'Add' => 'إضافة',
'Marks' => 'العلامات',
'Min Percentage' => 'النسبة الدنيا',
'Description' => 'الوصف',
'Attachment' => 'المرفق',
'Submit Date' => 'تاريخ التقديم',
'Select Related Course' => 'اختر الدورة ذات الصلة',
'Assign' => 'تعيين',
'Upload' => 'رفع',
'History' => 'التاريخ',
'Marking' => 'التقييم',
'Obtain Marks' => 'العلامات المحصلة',
'Anonymous' => 'مجهول',
'Staff' => 'الموظفين',
'Instructor' => 'المعلم',
'Student' => 'الطالب',
'Specific User' => 'المستخدم المحدد',
'Not Assigned' => 'غير معين',
'Pass' => 'ناجح',
'Fail' => 'راسب',
'Not Marked' => 'لم يتم التقييم',
'Not Submitted' => 'لم يتم التقديم'

];

