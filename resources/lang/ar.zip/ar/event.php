<?php

return [
    'title' => 'العنوان',
    'price' => 'السعر',
    'description' => 'الوصف',
    'conditions' => 'الشروط',
    'location' => 'الموقع',
    'created-at' => 'تاريخ الإنشاء',
    'action' => 'الإجراء',
    'edit' => 'تعديل',
    'delete' => 'حذف',
    'New Event'=>'اضافة حدث جديد'
];