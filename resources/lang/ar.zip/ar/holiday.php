<?php

return [
'Holidays of' => 'عطلة في',
'Days' => 'أيام',
'Purpose' => 'الغرض',
'Date' => 'التاريخ',
'Holiday Name' => 'اسم العطلة',
'Select Type' => 'اختر النوع',
'Single Day' => 'يوم واحد',
'Multiple Day' => 'أيام متعددة',
'Start Date' => 'تاريخ البدء',
'End Date' => 'تاريخ الانتهاء',
'Year' => 'سنة',
'Holiday Setup' => 'إعداد العطلة',
'Add New Year' => 'إضافة سنة جديدة',
'Holiday Copy From' => 'نسخ العطلة من',
'Select Year' => 'اختر السنة'

];

