<?php

return [
'Skill & Pathway' => 'المهارة والمسار',
'Skill' => 'المهارة',
'My Skill' => 'مهارتي',
'Browse Badge file' => 'استعراض ملف الشارة',
'Skill List' => 'قائمة المهارات',
'Badge' => 'شارة',
'Pathway' => 'المسار',
'Group' => 'المجموعة',
'Group List' => 'قائمة المجموعات',
'Group Student List' => 'قائمة طلاب المجموعة',
'Sub Groups' => 'مجموعات فرعية',
'Assign Students' => 'تعيين الطلاب',
'Pathway List' => 'قائمة المسارات',


];

