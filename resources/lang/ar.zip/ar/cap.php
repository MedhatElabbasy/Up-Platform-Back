<?php

return [
    "Currency Converter"=>"تحويل العملات",
    "Enter the price of the cap in riyals (SAR)"=>"ادخل سعر الكاب بالريال ",
    "Currency must be a number or decimal"=>"يجب أن تكون العملة رقمًا أو علامة عشرية",
    "Convert"=>"تحويل",

];
