<?php

return [
'Group' => 'مجموعة',
'Policy' => 'سياسة',
'Function' => 'وظيفة',
'Add Instructor' => 'إضافة مدرب',
'Assign Policy' => 'تعيين سياسة',
'Group Policy' => 'سياسة المجموعة',
    'Assign Courses' => 'تعين الدوره'
];
