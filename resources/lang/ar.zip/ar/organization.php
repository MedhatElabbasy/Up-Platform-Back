<?php
return [
'organization' => 'مؤسسة',
'Organization' => 'مؤسسة',
'financial_report' => 'تقرير مالي',
'sales_report' => 'تقرير المبيعات',
'income' => 'الدخل',
'topic' => 'موضوع',
'account_balance' => 'رصيد الحساب',
'ready_to_payout' => 'جاهز للدفع',
'total_income' => 'الإجمالي للدخل',
'payout_history' => 'سجل الدفع',
'request_payout' => 'طلب الدفع',
'payout_confirmation' => 'تأكيد الدفع',
'total_payout' => 'المبلغ المدفوع الكلي',
'account' => 'الحساب',
'completed' => 'مكتمل',
'confirmation' => 'تأكيد',
'admin_profit' => 'أرباح المشرف',
'account_type' => 'نوع الحساب',
'student' => 'طالب'
];
