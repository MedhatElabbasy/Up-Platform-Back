<?php

return [
'Page Builder' => 'مُنشئ الصفحات',
'Pages' => 'الصفحات',
'Page' => 'صفحة',
'Add New' => 'إضافة جديد',
'SL' => 'تسلسل',
'Title' => 'العنوان',
'Slug' => 'الرابط',
'Status' => 'الحالة',
'Body' => 'المحتوى',
'Create' => 'إنشاء',
'Create Page' => 'إنشاء صفحة',
'Update Page' => 'تحديث الصفحة',
'Design' => 'التصميم',
];
