<?php
return [
'Sponsor Saved Successfully' => 'تم حفظ الراعي بنجاح',
'Sponsor Deleted Successfully' => 'تم حذف الراعي بنجاح',
'Sponsor Updated Successfully' => 'تم تحديث الراعي بنجاح',
'Sponsors' => 'الرعاة',
'Add New Sponsor' => 'إضافة راعي جديد',
'Image' => 'الصورة',
'Title' => 'العنوان',
'Sponsor List' => 'قائمة الرعاة',
'Frontend CMS' => 'نظام إدارة المحتوى للواجهة الأمامية',

];
