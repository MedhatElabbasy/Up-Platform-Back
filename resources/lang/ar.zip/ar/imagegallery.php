<?php

return [
'Image Gallery' => 'معرض الصور',
'Manage Gallery' => 'إدارة المعرض',
'Add New Image' => 'إضافة صورة جديدة',
'Update Image' => 'تحديث الصورة',
'Add' => 'إضافة',
'Title' => 'العنوان',
'Image' => 'الصورة',
'Recommended size 200px x 200px' => 'الحجم الموصى به 200 بكسل × 200 بكسل',
'Recommended size 370px x 250px' => 'الحجم الموصى به 370 بكسل × 250 بكسل',
'Description' => 'الوصف',
'Status' => 'الحالة',
'Sorry ! Your gallery is empty' => 'عذرًا! معرض الصور فارغ'

];
