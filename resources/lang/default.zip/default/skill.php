<?php

return [
    'Skill & Pathway' => 'Skill & Pathway',
    'Skill' => 'Skill',
    'My Skill' => 'My Skill',
    'Browse Badge file' => 'Browse Badge file',
    'Skill List' => 'Skill List',
    'Badge' => 'Badge',
    'Pathway' => 'Pathway',
    'Group' => 'Group',
    'Group List' => 'Group List',
    'Group Student List' => 'Group Student List',
    'Sub Groups' => 'Sub Groups',
    'Assign Students' => 'Assign Students',
    'Pathway List' => 'Pathway List',

];

