<?php

return [
    'Group' => 'Group',
    'Policy' => 'Policy',
    'Function' => 'Function',
    'Add Instructor' => 'Add Instructor',
    'Assign Policy' => 'Assign Policy',
    'Group Policy' => 'Group Policy',
    'Assign Courses' => 'Assign Courses'
];
