<?php

return [
    'Role List' => 'Role List',
    'Role' => 'Role',
    'Instructor Role' => 'Instructor Role',
    'Details' => 'Details',
    'Role has been added Successfully' => 'Role has been added Successfully',
    'Role has been updated Successfully' => 'Role has been updated Successfully',
    'Edit Role Info' => 'Edit Role Info',
    'Role has been deleted Successfully' => 'Role has been deleted Successfully',
    'Permission' => 'Permission',
    'Menu' => 'Menu',
    'Sub-Menu' => 'Sub-Menu',
    'assign_permission' => 'Assign Permission',
    'role_permission' => 'Role Permission',
    'Student Role' => 'Student Role'
];
