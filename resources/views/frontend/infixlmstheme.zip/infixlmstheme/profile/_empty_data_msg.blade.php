<div class="alert alert-info text-center fs-14">
   {{trans('profile.no_data_available')}}
</div>
