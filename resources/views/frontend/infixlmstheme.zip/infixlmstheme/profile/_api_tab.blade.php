<div class="tab-pane fade" id="api_tab">
    <div class="row">
        <div class="col-12">
            @include(theme('profile.api._zoom'))
        </div>
    </div>
</div>
