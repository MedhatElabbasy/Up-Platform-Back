<!-- tutor cta:start -->
<div data-type="component-text" data-preview="{{asset('Modules/Appointment/Resources/assets/keditor/snippets/preview/affiliate/become_instructor_connect.png')}}" data-keditor-title="Instructor Connect" data-keditor-categories="Instructor Connect">

<section class="tutor_cta become_tutor">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="tutor_cta_inner">
                    <span>Get paid to teach online</span>
                    <h3>Connect with thousands of learners <span class="d-block">teach from your living room</span></h3>
                    <a href="#" class="theme_btn">Get Started Today</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- tutor cta:end -->