<div data-type="component-vimeo"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/vimeo.png')}}"
     data-aoraeditor-title="Vimeo" data-aoraeditor-categories="Media">
    <div class="vimeo-wrapper">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item"
                    src="https://player.vimeo.com/video/20570767?byline=0&portrait=0&badge=0"></iframe>
        </div>
    </div>
</div>
