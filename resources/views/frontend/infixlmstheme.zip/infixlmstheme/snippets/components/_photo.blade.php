<div data-type="component-text"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/photo.png')}}"
     data-aoraeditor-title="Photo" data-aoraeditor-categories="Media;Photo">
    <div class="photo-panel">
        <img src="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/img/somewhere_bangladesh.jpg')}}"
             width="100%"
             height=""/>
    </div>
</div>
