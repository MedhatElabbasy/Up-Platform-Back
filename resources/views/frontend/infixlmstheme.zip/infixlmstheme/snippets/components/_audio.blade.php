<div data-type="component-audio"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/audio.png')}}"
     data-aoraeditor-title="Audio" data-aoraeditor-categories="Media">
    <div class="audio-wrapper">
        <audio src="http://www.noiseaddicts.com/samples_1w72b820/2558.mp3" controls style="width: 100%"></audio>
    </div>
</div>
