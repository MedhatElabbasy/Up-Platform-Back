
<!-- sponsor:start -->
<section class="section_padding tutor sponsor">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center">

            <a href='#' class="sponsor_item"><img src="{{asset('Modules/Appointment/Resources/assets/frontend/')}}/img/sponsor/1.png" alt=""></a>
           
        </div>
    </div>
</section>
<!-- sponsor:end -->
