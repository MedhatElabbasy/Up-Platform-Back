<div data-type="component-text"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/affiliate/title.png')}}"
     data-aoraeditor-title="Affiliate Title" data-aoraeditor-categories="Affiliate Page">
    <div class="affiliate_bradcam_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="breadcam_text text-center">
                        <span>Join Our Affiliate Program</span>
                        <h3>Become a Part of Our Success
                            Earn Up-to 30% On Affiliate</h3>
                        <p>We offer attractive referral commissions for each successful </p>
                        <a href="{{url('/affiliate/registration')}}" class="theme_btn">Join Our Affiliate Family</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
