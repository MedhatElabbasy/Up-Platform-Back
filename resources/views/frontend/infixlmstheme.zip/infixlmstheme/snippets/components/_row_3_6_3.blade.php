<div data-type="container"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/row_3_6_3.png')}}"
     data-aoraeditor-title="3 columns (25% - 50% - 35%)" data-aoraeditor-categories="3 columns">
    <div class="row">
        <div class="col-sm-3" data-type="container-content">
        </div>
        <div class="col-sm-6" data-type="container-content">
        </div>
        <div class="col-sm-3" data-type="container-content">
        </div>
    </div>
</div>
