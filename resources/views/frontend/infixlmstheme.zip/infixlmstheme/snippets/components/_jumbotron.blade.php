<div data-type="component-text"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/jumbotron.png')}}"
     data-aoraeditor-title="Jumbotron" data-aoraeditor-categories="Text;Heading;Bootstrap component">
    <div class="jumbotron">
        <h1>Hello, world!</h1>
        <p>This is a simple hero unit</p>
        <p><a role="button" href="#" class="btn btn-primary btn-lg">Learn more</a></p>
    </div>
</div>
