<div data-type="container"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/row_12.png')}}"
     data-aoraeditor-title="1 column" data-aoraeditor-categories="1 column;Photo">
    <div class="row">
        <div class="col-sm-12" data-type="container-content">
        </div>
    </div>
</div>
