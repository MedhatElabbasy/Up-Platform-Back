<!-- tutor faq area:start -->
<div data-type="component-text" data-preview="{{asset('Modules/Appointment/Resources/assets/keditor/snippets/preview/affiliate/become_instructor_question.png')}}" data-keditor-title="Instructor FAQ" data-keditor-categories="Instructor FAQ">
<section class="section_padding become_tutor faq">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1 col-md-12">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="faq_inner_title m-0">
                            <h3>Frequently Asked Questions</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="faq_card">
                            <h4>Do you have offer refunds on business <span>Subscriptions?</span></h4>
                            <p>Consectetur adipiscing elit maecenas lobortis ac risus nec laoreet eget orci quis nisi lacinia gravida. Donec felis masspulvinar urna veleleifend commod odioestibulum rhoncus consequat.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="faq_card">
                            <h4>Do you have offer refunds on business <span>Subscriptions?</span></h4>
                            <p>Consectetur adipiscing elit maecenas lobortis ac risus nec laoreet eget orci quis nisi lacinia gravida. Donec felis masspulvinar urna veleleifend commod odioestibulum rhoncus consequat.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="faq_card">
                            <h4>Why do you ask for a video concept <span>introduction?</span></h4>
                            <p>Consectetur adipiscing elit maecenas lobortis ac risus nec laoreet eget orci quis nisi lacinia gravida. Donec felis masspulvinar urna veleleifend commod odioestibulum rhoncus consequat.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="faq_card">
                            <h4>What time zone should be fit for you <span>to be continue?</span></h4>
                            <p>Consectetur adipiscing elit maecenas lobortis ac risus nec laoreet eget orci quis nisi lacinia gravida. Donec felis masspulvinar urna veleleifend commod odioestibulum rhoncus consequat.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- tutor faq area:end -->