<div data-type="component-text"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/about/who_we_are.jpg')}}"
     data-aoraeditor-title="Who We Are" data-aoraeditor-categories="About Us Page">
    <div data-type="component-text"
         data-preview=""
         data-aoraeditor-title="Who We are" data-aoraeditor-categories="About Us Page">
        <div class="who_we_area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="who_we_info">
                            <div class="info_left">
                                <span>{{__('frontendmanage.Who We Are')}}</span>
                                <p>{{$about_page->who_we_are}}</p>
                            </div>
                            <div class="info_right">
                                <p>{{$about_page->banner_title}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
