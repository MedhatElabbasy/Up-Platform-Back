<div data-type="component-form"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/form.png')}}"
     data-aoraeditor-title="Bootstrap Form" data-aoraeditor-categories="Form;Bootstrap component">
</div>
