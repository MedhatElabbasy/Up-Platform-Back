<div data-type="component-googlemap"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/googlemap.png')}}"
     data-aoraeditor-title="Google Map" data-aoraeditor-categories="Gmap">
    <div class="googlemap-wrapper">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item"
                    src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d14897.682811563638!2d105.82315895!3d21.0158462!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1456466192755"></iframe>
        </div>
    </div>
</div>
