<div data-type="container"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/row_4_4_4.png')}}"
     data-aoraeditor-title="3 columns (33% - 33% - 33%)" data-aoraeditor-categories="3 columns">
    <div class="row">
        <div class="col-sm-4" data-type="container-content">
        </div>
        <div class="col-sm-4" data-type="container-content">
        </div>
        <div class="col-sm-4" data-type="container-content">
        </div>
    </div>
</div>
