<div data-type="component-text" data-preview="{{asset('')}}Modules/Appointment/Resources/assets/keditor/snippets/preview/affiliate/feature_05.png" data-keditor-title="Feature 05" data-keditor-categories="Feature 05">
<!-- tutor cta:start -->
<section class="tutor_cta">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="tutor_cta_inner">
                    <span>100% Satisfaction Guarantee</span>
                    <h3>If you are not satisfied with your trial lesson <span class='d-block'>we will give you a free replacement</span></h3>
                    <a href="#" class="theme_btn">Read Student Reviews</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- tutor cta:end -->
</div>