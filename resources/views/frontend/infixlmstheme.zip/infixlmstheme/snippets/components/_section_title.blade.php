<div data-type="component-text"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/home/homepage_faq_section.jpg')}}"
     data-aoraeditor-title="Section Title" data-aoraeditor-categories="App Page">

    <div class="blog_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-8">
                    <div class="section__title text-center mb_80">
                        <h3>
                            Download Mobile App
                        </h3>
                        <p>
                            We are available on Play-store & Appstore
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
