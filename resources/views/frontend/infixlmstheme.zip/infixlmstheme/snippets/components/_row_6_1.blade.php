<div data-type="container"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/row_4_8.png')}}"
     data-aoraeditor-title="2 columns (33% - 67%)" data-aoraeditor-categories="2 columns">
    <div class="row">
        <div class="col-sm-4" data-type="container-content">
        </div>
        <div class="col-sm-8" data-type="container-content">
        </div>
    </div>
</div>
