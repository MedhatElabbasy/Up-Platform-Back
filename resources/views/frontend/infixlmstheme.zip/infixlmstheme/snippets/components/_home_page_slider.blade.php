<div data-type="component-text"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/home/homepage_banner.jpg')}}"
     data-aoraeditor-title="HomePage Slider" data-aoraeditor-categories="Home Page" class="__banner">
    <div data-type="component-nonExisting"
         data-preview=""
         data-table=""
         data-select=""
         data-order="id"
         data-limit=""
         data-where-status="1"
         data-view="_single_slider"
         data-model="Modules\FrontendManage\Entities\Slider"
         data-with=""
         data-with-count=""
    >
        <div class="dynamicData"
             data-dynamic-href="{{routeIsExist('getDynamicData')?route('getDynamicData'):''}}"></div>
    </div>
</div>
