<div data-type="component-text"
     data-preview="{{asset('')}}Modules/Appointment/Resources/assets/keditor/snippets/preview/affiliate/feature_02.png"
     data-keditor-title="Feature 02" data-keditor-categories="Feature 02">
    <!-- post request:start -->
    <section class="section_padding_off ins_cta">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="ins_cta_inner">
                        <div class="row">
                            <div class="col-lg-8 offset-lg-2">
                                <div class="ins_cta_inner_text">
                                    <span>Request a Private Tutor</span>
                                    <h3>Post your requirements <br>let tutors find you.</h3>
                                    <a href="{{ validRouteUrl('appointment.post.index') }}"
                                       class="theme_btn small_btn2">Post Request</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- post request:end -->
</div>
