<div data-type="component-text"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/heading_2.png')}}"
     data-aoraeditor-title="Heading 2" data-aoraeditor-categories="Text;Heading">
    <h2>Heading text 2</h2>
    <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.
        Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
</div>
