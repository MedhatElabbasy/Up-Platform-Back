<div data-type="component-nonExisting"
     data-preview=""
     data-table=""
     data-select=""
     data-order="id"
     data-limit="0"
     data-partial="_menu"
     data-model=""
     data-with=""
     data-aoraeditor-title="Header"
     data-aoraeditor-categories="Common">

    <div class="dynamicData"
         data-dynamic-href="{{routeIsExist('getDynamicData')?route('getDynamicData'):''}}"></div>

</div>
