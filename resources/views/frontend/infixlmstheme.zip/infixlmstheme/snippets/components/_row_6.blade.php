<div data-type="container"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/row_6_6.png')}}"
     data-aoraeditor-title="2 columns (50% - 50%)" data-aoraeditor-categories="2 columns">
    <div class="row">
        <div class="col-sm-6" data-type="container-content">
        </div>
        <div class="col-sm-6" data-type="container-content">
        </div>
    </div>
</div>
