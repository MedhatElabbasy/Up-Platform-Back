<div data-type="component-video"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/video.png')}}"
     data-aoraeditor-title="Video" data-aoraeditor-categories="Media">
    <div class="video-wrapper">
        <video width="320" height="180" controls style="background: #222;" data-ratio="16/9">
            <source src="http://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4"/>
            <source src="http://www.w3schools.com/html/mov_bbb.ogg" type="video/ogg"/>
        </video>
    </div>
</div>
