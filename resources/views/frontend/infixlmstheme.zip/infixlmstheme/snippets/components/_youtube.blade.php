<div data-type="component-youtube"
     data-preview="{{!function_exists('themeAsset')?'':themeAsset('img/snippets/preview/youtube.png')}}"
     data-aoraeditor-title="Youtube" data-aoraeditor-categories="Media">
    <div class="youtube-wrapper">
        <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/P5yHEKqx86U"></iframe>
        </div>
    </div>
</div>
