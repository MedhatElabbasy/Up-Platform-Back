<div>
    @if(!$isWaiting)
        <span class="class_close_tag"><span>{{__('frontend.Closed')}}</span></span>
    @endif
</div>
