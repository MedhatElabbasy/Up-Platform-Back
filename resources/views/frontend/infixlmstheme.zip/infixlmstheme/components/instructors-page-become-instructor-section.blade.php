<div>
    <div class="cta_area">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 offset-xl-1">
                    <div class="section__title white_text">
                        <h3 class="large_title">{{@$homeContent->become_instructor_title}}</h3>
                        <p> {{@$homeContent->become_instructor_sub_title}}</p>
                        <a href="{{route('becomeInstructor')}}"
                           class="theme_btn small_btn">{{__('frontend.Start Teaching')}}</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
