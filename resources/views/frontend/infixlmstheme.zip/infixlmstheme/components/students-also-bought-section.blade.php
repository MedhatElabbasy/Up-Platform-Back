<div>
    <!-- He who is contented is rich. - Laozi -->
</div>