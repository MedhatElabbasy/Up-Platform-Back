<div>
    <div class="instractors_wrapper instractors_wrapper2">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="section__title2 mb_76">
                        <br>
                        <span>{{__('frontend.Meet Our world-class Consultants')}}</span>
                        <h4>{{__('frontend.We are here to meet your demand and teach the most beneficial way for you in Personal')}}
                            .</h4>
                    </div>
                </div>
            </div>
            <div class="row" id="results">
                <div class="ajax-loading">

                    <svg version="1.1" id="L4" xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100"
                         enable-background="new 0 0 0 0" xml:space="preserve"> <circle fill="#7c32ff" stroke="none"
                                                                                       cx="6" cy="50" r="6">
                            <animate attributeName="opacity" dur="1s" values="0;1;0" repeatCount="indefinite"
                                     begin="0.1"></animate>
                        </circle>
                        <circle fill="#7c32ff" stroke="none" cx="26" cy="50" r="6">
                            <animate attributeName="opacity" dur="1s" values="0;1;0" repeatCount="indefinite"
                                     begin="0.2"></animate>
                        </circle>
                        <circle fill="#7c32ff" stroke="none" cx="46" cy="50" r="6">
                            <animate attributeName="opacity" dur="1s" values="0;1;0" repeatCount="indefinite"
                                     begin="0.3"></animate>
                        </circle>
                        </svg>

                </div>


            </div>
        </div>
    </div>
</div>
