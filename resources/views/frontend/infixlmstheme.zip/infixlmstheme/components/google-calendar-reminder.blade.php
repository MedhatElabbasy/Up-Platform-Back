<a target="_blank"
   href="https://calendar.google.com/calendar/render?action=TEMPLATE&amp;dates={{@$start_time}}/{{@$end_time}}&amp;ctz={{Settings('active_time_zone')}}&amp;text={{@$title}}"
   class="theme_line_btn d-block text-center height_50 mb_20">{{__('frontend.Reminder')}}</a>
